package com.example.demo.Service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.CustomerDTO;
import com.example.demo.DTO.CustomerSaveDTO;
import com.example.demo.DTO.CustomerUpdateDTO;
import com.example.demo.Exception.ResourceNotFound;
import com.example.demo.Model.CustomerRegister;
import com.example.demo.Repository.CustomerRegisterRepo;

@Service
public class CustomerServiceIMPL implements CustomerService {
	@Autowired
	private CustomerRegisterRepo customerRepo;

	@Override
	public String addCustomer(CustomerSaveDTO customerSaveDTO) {
		CustomerRegister customer = new CustomerRegister(0, customerSaveDTO.getFirstname(),
				customerSaveDTO.getLastname(), customerSaveDTO.getUsername(), customerSaveDTO.getPassword(),
				customerSaveDTO.getEmail(), customerSaveDTO.getPhoneNo(), customerSaveDTO.getLocation());
		customerRepo.save(customer);
		return customer.getFirstname();
	}

	@Override
	public List<CustomerDTO> getAllCustomers() {
		List<CustomerRegister> getCustomer = customerRepo.findAll();
		List<CustomerDTO> CustomerDTOList = new ArrayList<>();
		for (CustomerRegister a : getCustomer) {
			CustomerDTO customerDTO = new CustomerDTO(a.getcId(), a.getFirstname(), a.getLastname(), a.getUsername(),
					a.getPassword(), a.getEmail(), a.getPhoneNo(), a.getLocation());
			CustomerDTOList.add(customerDTO);
		}

		return CustomerDTOList;
	}

	@Override
	public boolean deleteCustomer(int id) {

		if (customerRepo.existsById(id)) {
			customerRepo.deleteById(id);
		} else {
			System.out.println("Customer ID is Not found..");
		}
		return true;
	}

	@Override

	public CustomerRegister updateCustomer(CustomerRegister customer, int id) {
		CustomerRegister existingCustomer = customerRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFound("Customer", "Id", "id"));
		existingCustomer.setFirstname(customer.getFirstname());
		existingCustomer.setLastname(customer.getLastname());
		existingCustomer.setUsername(customer.getUsername());
		existingCustomer.setPassword(customer.getPassword());
		existingCustomer.setEmail(customer.getEmail());
		existingCustomer.setPhoneNo(customer.getPhoneNo());
		existingCustomer.setLocation(customer.getLocation());

		customerRepo.save(existingCustomer);

		return existingCustomer;
	}

	@Override
	public List<CustomerRegister> getAllCustomerByUsername(String username) {
	return  customerRepo.findAllCustomerByUsername(username);
	}

	



}
