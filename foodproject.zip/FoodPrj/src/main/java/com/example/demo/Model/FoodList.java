package com.example.demo.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FoodList")
public class FoodList {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "foodid")
	private int FoodId;
	@Column(name = "foodname")
	private String FoodName;
	@Column(name = "foodprice")
	private String foodprice;
	@Column(name = "foodimage")
	private String foodimage;
	public FoodList() {

	}

	public int getFoodId() {
		return FoodId;
	}

	public void setFoodId(int foodId) {
		FoodId = foodId;
	}

	public String getFoodName() {
		return FoodName;
	}

	public void setFoodName(String foodName) {
		FoodName = foodName;
	}

	public String getFoodprice() {
		return foodprice;
	}

	public void setFoodprice(String foodprice) {
		this.foodprice = foodprice;
	}

	

	public String getFoodimage() {
		return foodimage;
	}

	public void setFoodimage(String foodimage) {
		this.foodimage = foodimage;
	}

	public FoodList(int foodId, String foodName, String foodprice, String foodimage) {
		super();
		FoodId = foodId;
		FoodName = foodName;
		this.foodprice = foodprice;
		this.foodimage = foodimage;

	}

	@Override
	public String toString() {
		return "FoodList [FoodId=" + FoodId + ", FoodName=" + FoodName + ", foodprice=" + foodprice + ",  foodimage=" + foodimage + "]";
	}

}
