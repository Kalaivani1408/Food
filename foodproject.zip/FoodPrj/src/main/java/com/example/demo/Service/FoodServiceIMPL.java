package com.example.demo.Service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.FoodDTO;
import com.example.demo.DTO.FoodSaveDTO;
import com.example.demo.Exception.ResourceNotFound;
import com.example.demo.Model.FoodList;
import com.example.demo.Repository.FoodListRepo;

@Service
public class FoodServiceIMPL implements FoodService{
	@Autowired
	private FoodListRepo foodRepo;


	@Override
	public String addfood(FoodSaveDTO foodSaveDTO) {
		 FoodList food=new  FoodList(0,foodSaveDTO.getFoodName(),foodSaveDTO.getFoodprice(),foodSaveDTO.getFoodimage());
		 foodRepo.save(food);
		return food.getFoodName();
	}

	@Override
	public List<FoodDTO> getAllFood() {
		List<FoodList>getFood=foodRepo.findAll();
		List<FoodDTO>foodDTOList=new ArrayList<>();
		for(FoodList a:getFood)
		{
			FoodDTO foodDTO=new FoodDTO(a.getFoodId(),a.getFoodName(),a.getFoodprice(),
					a.getFoodimage());
			foodDTOList.add(foodDTO);
		}
		
		return foodDTOList;
	}

	

	@Override
	public boolean deleteFood(int id) {
		if(foodRepo.existsById(id))
		{
			foodRepo.deleteById(id);
		}
		else
		{
			System.out.println("Food ID is Not found..");
		}
			return true;
		}

	@Override
	public FoodList updateFood(FoodList food, int id) {
	
		FoodList existingFood=foodRepo.findById(id).orElseThrow(()->new ResourceNotFound("Customer","Id","id"));
		existingFood.setFoodId(food.getFoodId());
		existingFood.setFoodName(food.getFoodName());
		existingFood.setFoodprice(food.getFoodprice());
		existingFood.setFoodimage(food.getFoodimage());
		
		foodRepo.save(existingFood);
		
		return existingFood;
	}
	@Override
	public FoodList getFoodById(int id) {
		// TODO Auto-generated method stub
		return foodRepo.findById(id).orElseThrow(()->new ResourceNotFound("FoodList","id",id));
		
	}
}
