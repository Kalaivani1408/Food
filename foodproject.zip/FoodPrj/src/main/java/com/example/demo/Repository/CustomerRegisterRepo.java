package com.example.demo.Repository;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.CustomerRegister;



public interface CustomerRegisterRepo extends JpaRepository<CustomerRegister,Integer>{
	List<CustomerRegister>findAllCustomerByUsername(String username);

}
