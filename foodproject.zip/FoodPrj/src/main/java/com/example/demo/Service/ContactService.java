package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.ContactDTO;
import com.example.demo.DTO.ContactSaveDTO;
import com.example.demo.Model.Contact;
import com.example.demo.Model.CustomerRegister;

public interface ContactService {
	String addContact(ContactSaveDTO contacsaveDTO );
	List<ContactDTO>getAllContact();
	boolean deleteContact(int id);
	
}

