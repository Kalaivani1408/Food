package com.example.demo.Model;

import javax.persistence.*;

@Entity
public class Contact {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private int id;
    private String name;
	private String email;
    private long phoneno;
    private String message;
    
	public Contact() {
		
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Contact(int id,String name, String email, long phoneno, String message) {
		this.id=id;
		this.name = name;
		this.email = email;
		this.phoneno = phoneno;
		this.message = message;
	}
	@Override
	public String toString() {
		return "Contact [id=" + id + ", name=" + name + ", email=" + email + ", phoneno=" + phoneno + ", message="
				+ message + "]";
	}

	
}
